function val = mytrace(A,B);

if (~iscell(A) & ~iscell(B)) 
                    
   if (nargin == 1)
      val = sum(diag(A));
   elseif (nargin == 2)
      val = sum(sum(A.*B));
   end

elseif (iscell(A) & iscell(B))
       if (nargin == 1)
      val = sum(diag(A{1}));
   elseif (nargin == 2)
      val = sum(sum(A{1}.*B{1}));
   end
    
end
return