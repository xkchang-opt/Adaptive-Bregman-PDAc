function [IM,FOM,results] = ReconHOTVPDM_adaptive(A,ReconData,ReconParam)
%% Input Variables
%A:The System Matrix;
%Data: 1.g(sinogram); 2.gamma(the sum of Random and Scatter);
%      3.InitIM;      4.PerfPhantom(Perfect Phantom).
%ReconParam: 1.ITER; 2.lambda1; 3.lambda2.

%% Output Variables
%IM:The reconstucted image
%FOM(Figure of Merit):
%1.OFV(Objective function Value)
%2.PSNR(Peak Signal to Noise Ratio)
%3.NRMSE(Normlized Root Mean Squar Error)

%% HOTV Initialization
AT1 = A'*ones([size(A,1) 1]);
f = ReconData.InitIM;
dimf = numel(f);
nR = sqrt(dimf);
nLOR = size(ReconData.sinogram,1);
nPhi = size(ReconData.sinogram,2);
g = reshape(ReconData.sinogram,[nLOR*nPhi 1]);
gamma = ReconData.gamma;
object = reshape(ReconData.PerfPhantom,[dimf 1]);
ITER = ReconParam.ITER;
MAX = max(object);
lambda1 = ReconParam.lambda1;
lambda2 = ReconParam.lambda2;
t = sqrt(ReconParam.betaR);

b = zeros(2*dimf,1);
c = zeros(4*dimf,1);
FOM.OFV = zeros(ITER,1);    %Objective Funtion Value
FOM.NRMSE = zeros(ITER,1);   %Root Mean Squar Error
FOM.PSNR = zeros(ITER,1);   %Peak Signal to Noise Ratio
FOM.IterTime = zeros(ITER,1);

%% initial step sizes
tau = 0.01;
tau0 = tau;
rho1 = 1;
rho2 = 1;
v = 1.2; 
epslon = 1e-6;
results = [];
disp('**********************************************************')
disp('Adaptive PDM for Regularized PET image reconstruction')
disp('**********************************************************') 
%% HOTV Reconstruction
for k = 1:ITER
    tic;
    Af = A*f;
%% Update f
    g_Af_gmma = g./(Af+gamma);
    if k >=2; ORI_q = q; end
    q = AT1-A'*g_Af_gmma;
    
    if k >=2; 
        rs = ORI_q - q;
        rf = ORI_f-f;
        L = norm(rs)^2 / mytrace(rs, rf);
        C = mytrace(rs, rf) / norm(rf)^2;
        delta = tau * L * (tau*C - 1);
        xi = t^2 * tau^2;
    end    
    subgrad = q + FirstOrderDiffTrans(b)+SecondOrderDiffTrans(c);
    ORI_f = f; 
    f = ORI_f - tau*subgrad;
    f(f<0) = 0;

%% Update step sizes
    if k >=2 
        temp = 1-4*xi*(1+epslon)^2;
        gs = tau * sqrt(temp/ (2*(1+epslon)*(delta+sqrt(delta^2+xi*temp))));
        tau1 = min(min(tau * sqrt(1+tau/tau0), 1/(2*v*t)), gs); 
        tau0 = tau; 
        tau = tau1;
       
        rho1 = t^2*tau/(2*8);
        rho2 = t^2*tau/(2*64);
    end 
%% Update b and c
    bar_f = (1+tau/tau0)*f - (tau/tau0) * ORI_f;
    B1f = FirstOrderDiff(bar_f);
    b_B1f = 1/rho1*b+B1f;
    z1 = b_B1f(1:dimf);
    z2 = b_B1f(dimf+1:2*dimf);
    z3 = sqrt(z1.^2+z2.^2);
    b_prox = zeros(2*dimf,1);
    ii = find(z3>lambda1/rho1);
    b_prox(ii) = (1-lambda1/rho1*(1./z3(ii))).*z1(ii);
    b_prox(dimf+ii) = (1-lambda1/rho1*(1./z3(ii))).*z2(ii);
    b = rho1*(b_B1f - b_prox);
    
    B2f = SecondOrderDiff(bar_f);
    c_B2f = 1/rho2*c+B2f;
    z1 = c_B2f(1:dimf);
    z2 = c_B2f(dimf+1:2*dimf);
    z3 = c_B2f(2*dimf+1:3*dimf);
    z4 = c_B2f(3*dimf+1:4*dimf);
    z5 = sqrt(z1.^2+z2.^2+z3.^2+z4.^2);
    c_prox = zeros(4*dimf,1);
    ii = find(z5>lambda2/rho2);
    c_prox(ii) = (1 - lambda2/rho2*(1./z5(ii))).*z1(ii);
    c_prox(dimf+ii) = (1 - lambda2/rho2*(1./z5(ii))).*z2(ii);
    c_prox(2*dimf+ii) = (1 - lambda2/rho2*(1./z5(ii))).*z3(ii);
    c_prox(3*dimf+ii) = (1 - lambda2/rho2*(1./z5(ii))).*z4(ii);
    c = rho2*(c_B2f - c_prox);
    
%% obtain results    
    FOM.IterTime(k)=toc;
    if mod(k,50)==0
        fprintf('HOTV-adpPDM: The %dth iteration costs %f seconds\n',k,FOM.IterTime(k));
    end
    
    penalty1 = lambda1*FirstOrderITV(f);
    penalty2 = lambda2*SecondOrderITV(f);
    FOM.OFV(k) = sum(Af)-sum(g.*log(Af+gamma))+penalty1+penalty2;
    MSE = (norm(object-f,2)^2)/dimf;
    FOM.PSNR(k) = 10*log10(MAX*MAX/MSE);
    FOM.NRMSE(k) = (norm(object-f,2))/(1+norm(object,2));
    if ismember(k,1:200);
        results = [results tau];
    end
end
fprintf('The total time of %d HOTV-adpPGM iterations is: %f seconds\n',ITER, sum(FOM.IterTime(:)));
%fprintf('The average time of HOTV-adpPGM for each iteration is: %f seconds\n',sum(FOM.IterTime(:))/ITER);
IM = reshape(f,[nR nR]);

end

