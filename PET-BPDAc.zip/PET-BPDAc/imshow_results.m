f = ReconData.InitIM;
dimf = numel(f);
nR = sqrt(dimf);
maxIM = max(ReconData.PerfPhantom(:));
results1 = [results1 reshape(ReconData.PerfPhantom,[dimf 1])];

for i=1:6;
    figure;
    IM = reshape(results1(:,i),[nR nR]);
    IM = IM(30:226,30:226);
    imshow(maxIM-IM,[0,maxIM],'border','tight');
end