function plotfunc(FOM1, FOM2, FOM3, FOM4, FOM5, label1, label2, label3, label4, label5)
lw = 2;

% �������������� 
figure;
semilogy(cumsum(FOM1.IterTime), FOM1.OFV, '-b', 'LineWidth', lw); hold on;
semilogy(cumsum(FOM2.IterTime), FOM2.OFV, '-k', 'LineWidth', lw);  % 
semilogy(cumsum(FOM3.IterTime), FOM3.OFV, '-c', 'LineWidth', lw);  % 
semilogy(cumsum(FOM4.IterTime), FOM4.OFV, '-m', 'LineWidth', lw);  % 
semilogy(cumsum(FOM5.IterTime), FOM5.OFV, '-r', 'LineWidth', lw);  % 
legend({label1, label2, label3, label4, label5}, 'FontSize', 14);
xlabel('CPU time, seconds','FontSize', 14); ylabel('Objective function value','FontSize', 14);
set(gca, 'FontSize', 14);

% ����NRMSE����
figure;
plot(cumsum(FOM1.IterTime), FOM1.NRMSE, '-b', 'LineWidth', lw); hold on;
plot(cumsum(FOM2.IterTime), FOM2.NRMSE, '-k', 'LineWidth', lw);  % 
plot(cumsum(FOM3.IterTime), FOM3.NRMSE, '-c', 'LineWidth', lw);  % 
plot(cumsum(FOM4.IterTime), FOM4.NRMSE, '-m', 'LineWidth', lw);  % 
plot(cumsum(FOM5.IterTime), FOM5.NRMSE, '-r', 'LineWidth', lw);  % 
legend({label1, label2, label3, label4, label5}, 'FontSize', 14);
xlabel('CPU time, seconds', 'FontSize', 14); ylabel('NRMSE', 'FontSize', 14);
set(gca, 'FontSize', 14);

% ����PSNR����
figure;
plot(cumsum(FOM1.IterTime), FOM1.PSNR, '-b', 'LineWidth', lw); hold on;
plot(cumsum(FOM2.IterTime), FOM2.PSNR, '-k', 'LineWidth', lw);  % 
plot(cumsum(FOM3.IterTime), FOM3.PSNR, '-c', 'LineWidth', lw);  % 
plot(cumsum(FOM4.IterTime), FOM4.PSNR, '-m', 'LineWidth', lw);  % 
plot(cumsum(FOM5.IterTime), FOM5.PSNR, '-r', 'LineWidth', lw);  % 
legend({label1, label2, label3, label4, label5}, 'FontSize', 14);
xlabel('CPU time, seconds','FontSize', 14); ylabel('PSNR','FontSize', 14);
set(gca, 'FontSize', 14);

end