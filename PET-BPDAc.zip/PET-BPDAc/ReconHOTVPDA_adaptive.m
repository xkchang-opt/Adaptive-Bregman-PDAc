function [IM,FOM,results] = ReconHOTVPDA_adaptive(A,ReconData,ReconParam)
%% Input Variables
%A:The System Matrix;
%Data: 1.g(sinogram); 2.gamma(the sum of Random and Scatter);
%      3.InitIM;      4.PerfPhantom(Perfect Phantom).
%ReconParam: 1.ITER; 2.lambda1; 3.lambda2.

%% Output Variables
%IM:The reconstucted image
%FOM(Figure of Merit):
%1.OFV(Objective function Value)
%2.PSNR(Peak Signal to Noise Ratio)
%3.NRMSE(Normlized Root Mean Squar Error)

%% HOTV Initialization
AT1 = A'*ones([size(A,1) 1]);
f = ReconData.InitIM;
dimf = numel(f);
nR = sqrt(dimf);
nLOR = size(ReconData.sinogram,1);
nPhi = size(ReconData.sinogram,2);
g = reshape(ReconData.sinogram,[nLOR*nPhi 1]);
gamma = ReconData.gamma;
object = reshape(ReconData.PerfPhantom,[dimf 1]);
ITER = ReconParam.ITER;
MAX = max(object);
lambda1 = ReconParam.lambda1;
lambda2 = ReconParam.lambda2;
use_M = ReconParam.use_M;

r = 3;
r0 = r;
rho = 6/5;   
xi = 2-2/r;
it_pinf = 0;
it_dinf = 0;

beta = ReconParam.betaR;
psi = ReconParam.psi;

b = zeros(2*dimf,1);
c = zeros(4*dimf,1);
FOM.OFV = zeros(ITER,1);    %Objective Funtion Value
FOM.NRMSE = zeros(ITER,1);   %Root Mean Squar Error
FOM.PSNR = zeros(ITER,1);   %Peak Signal to Noise Ratio
FOM.IterTime = zeros(ITER,1);

%% initial step sizes
if use_M == 1; tau = 1; else tau = 0.01; end 
tau0 = tau;
results = [];

preAT1 = AT1;
preAT1(preAT1<=0) = 1;
Af = A*f;
g_Af_gmma = g./(Af+gamma);
q = AT1-A'*g_Af_gmma;
v = f;
%% HOTV Reconstruction
disp('**********************************************************')
disp('Adaptive Bregman PDAc for Regularized PET image reconstruction')
disp('**********************************************************') 
for k = 1:ITER
    tic;
    ORI_f = f; 
%% Update f  
    subgrad = q + FirstOrderDiffTrans(b)+SecondOrderDiffTrans(c);    
%% using convex combination 
     v = ((psi-1)/psi) *f + (1/psi)*v;
     if use_M == 1
         if k <= 30
             inv_M = max(0.1,f)./preAT1;   M = 1./inv_M;    S = max(inv_M);             
         end
     else
         inv_M = ones(dimf,1);   M = inv_M;    S = 1;
     end          
     f = v - tau*(inv_M.*subgrad);
     f(f<0) = 0;
 
     ORI_q = q; 
     Af1 = A*f;
     g_Af_gmma = g./(Af1+gamma);
     q = AT1-A'*g_Af_gmma; 
%% Update step sizes
    qq = q - ORI_q; ff = f - ORI_f;
    L_s2 = mytrace(qq, inv_M.*qq) / mytrace(ff, M.*ff);
    pds = psi*xi/(beta*tau*S +psi^3/((1+psi)*tau));
    gs = psi^2/(r*r0 * L_s2 *tau0);
    tau1 = min(min(rho*tau, pds), gs);
    tau0 = tau;  tau = tau1;
 
    [r1, it_pinf,it_dinf] = adaptive_r(k, pds, gs, r, it_pinf,it_dinf);
    r0 = r;  r = r1;  xi = 2-2/r;             
    rho1 = beta*tau/(2*8);
    rho2 = beta*tau/(2*64);   
    
%% Update b and c
    B1f = FirstOrderDiff(f);
    b_B1f = 1/rho1*b+B1f;
    z1 = b_B1f(1:dimf);
    z2 = b_B1f(dimf+1:2*dimf);
    z3 = sqrt(z1.^2+z2.^2);
    b_prox = zeros(2*dimf,1);
    ii = find(z3>lambda1/rho1);
    b_prox(ii) = (1-lambda1/rho1*(1./z3(ii))).*z1(ii);
    b_prox(dimf+ii) = (1-lambda1/rho1*(1./z3(ii))).*z2(ii);
    b = rho1*(b_B1f - b_prox);
    
    B2f = SecondOrderDiff(f);
    c_B2f = 1/rho2*c+B2f;
    z1 = c_B2f(1:dimf);
    z2 = c_B2f(dimf+1:2*dimf);
    z3 = c_B2f(2*dimf+1:3*dimf);
    z4 = c_B2f(3*dimf+1:4*dimf);
    z5 = sqrt(z1.^2+z2.^2+z3.^2+z4.^2);
    c_prox = zeros(4*dimf,1);
    ii = find(z5>lambda2/rho2);
    c_prox(ii) = (1 - lambda2/rho2*(1./z5(ii))).*z1(ii);
    c_prox(dimf+ii) = (1 - lambda2/rho2*(1./z5(ii))).*z2(ii);
    c_prox(2*dimf+ii) = (1 - lambda2/rho2*(1./z5(ii))).*z3(ii);
    c_prox(3*dimf+ii) = (1 - lambda2/rho2*(1./z5(ii))).*z4(ii);
    c = rho2*(c_B2f - c_prox);
%----------------------------------------------------------------------------    
%% obtain results 
    FOM.IterTime(k)=toc;
    if mod(k,50)==0
        fprintf('HOTV-adpPDA: The %dth iteration costs %f seconds\n',k,FOM.IterTime(k));
    end
    
    penalty1 = lambda1*FirstOrderITV(f);
    penalty2 = lambda2*SecondOrderITV(f);
    FOM.OFV(k) = sum(Af)-sum(g.*log(Af+gamma))+penalty1+penalty2; Af = Af1;
    MSE = (norm(object-f,2)^2)/dimf;
    FOM.PSNR(k) = 10*log10(MAX*MAX/MSE);
    FOM.NRMSE(k) = (norm(object-f,2))/(1+norm(object,2));
    if ismember(k,1:100);
        results = [results tau*mean(inv_M)];
    end
        
end
fprintf('The total time of %d HOTV-adpPDA iterations is: %f seconds\n',ITER,sum(FOM.IterTime(:)));
%fprintf('The average time of HOTV-adpPDA for each iteration is: %f seconds\n',sum(FOM.IterTime(:))/ITER);
IM = reshape(f,[nR nR]);

end

