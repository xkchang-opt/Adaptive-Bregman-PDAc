clear;
close all;
clc;

%% Choose the Phantom
PhanNum = 1;

if PhanNum == 1
    load('Brain256.mat');
    Myphantom = Brain256;
elseif PhanNum == 2
    load('UniformPhantom.mat');
    Myphantom = UniformPhantom;
else
    error('PhanNum can only be 1 or 2!!')
end

% Parameters for HOTV
% lambda=0.34 for Brain Phantom(lowcount); lambda=0.8 for Lumpy Phantom.
if PhanNum == 1
    ReconParam.lambda1 = 0.04; 
    ReconParam.lambda2 = 0.04;
    ReconParam.betaR = 0.1;  %% ratio of step 
else
    ReconParam.lambda1 = 0.4;
    ReconParam.lambda2 = 0;
    ReconParam.betaR = 2;  %% ratio of step 
end
  

%% Load the geometry projection matrix A
matName = 'Amat_256x256_77LORx288P_300FOV_4DW_32Ray.mat';
isFile = exist(matName, 'file');
if (isFile == 2)
    tic;
    load(matName);
    LoadA=toc;
    fprintf('It costs %f seconds to load the system matrix A\n',LoadA);
else
    error('!!! No matrix available !!!')
end

%% Generate system matrix and sinogram
[A,ReconData] = GenerateSino(A,Myphantom);
nLOR = size(ReconData.sinogram,1);
nPhi = size(ReconData.sinogram,2);
h = reshape(ReconData.sinogram,[nLOR*nPhi 1]);
gamma = ReconData.gamma;
% svds(A, 1) = 269.9675;
%L_s = norm(h,inf)*269.9675^2/norm(gamma,inf)^2;
L_s = 100;

%% Parameters for Reconstruction
ReconParam.ITER = 200; % Maximal number of iterations

%% Parameters for Bregman PDA with convex combination
ReconParam.psi = 2;   %% convex combination parameter

%%
ReconParam.use_M = 1;
[adPDAr_IM, adPDAr_FOM, results1] = ReconHOTVPDA_adaptive(A, ReconData, ReconParam); 
%%
ReconParam.tau = 0.005;
[GR_IM, GR_FOM] = ReconHOTV_GR(A, ReconData, ReconParam); 
ReconParam.tau = 0.002;
[CV_IM, CV_FOM] = ReconHOTV_CV(A, ReconData, ReconParam);

ReconParam.use_M = 0;
[adPDA_IM, adPDA_FOM,results2] = ReconHOTVPDA_adaptive(A, ReconData, ReconParam);

%%
[adPDM_IM, adPDM_FOM, results3] = ReconHOTVPDM_adaptive(A, ReconData, ReconParam); 

maxIM = max(ReconData.PerfPhantom(:));

plotfunc(CV_FOM, GR_FOM, adPDM_FOM, adPDA_FOM, adPDAr_FOM,  'Condat-Vu', 'eGRPDA', 'adpPDM','adpBPDAc-I','adpBPDAc');