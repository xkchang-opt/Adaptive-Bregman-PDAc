function [r, it_pinf,it_dinf] = adaptive_r(iter, pds, gs, r, it_pinf,it_dinf)

    rmin = 3;
    rmax = 20;

 dtmp=pds/gs;  
 if iter<=21;         kk=3;
 elseif iter<=61;     kk=6;    
 elseif iter<=121;    kk=20;
 else                kk=50;  
 end

 if dtmp <= 0.8;   it_pinf = it_pinf+1;     it_dinf = 0;
    if it_pinf>kk
       r = min(5/4 *r,rmax);
       it_pinf=0;
    end
  else if dtmp > 1.25;    it_dinf = it_dinf+1; it_pinf = 0;
          if it_dinf>kk
             r = max(4/5 *r, rmin);        
             it_dinf = 0;
          end
       end
 end
 
 
end