function [penalty] = FirstOrderITV(f)
Bf = FirstOrderDiff(f);
d = numel(f);

p = zeros(d,1);
for i = 1:d
    p(i) = sqrt(Bf(i)^2+Bf(d+i)^2);
end
%------------------------------------------------------------------
%Field of View Fisrt-Order ITV Penalty
%------------------------------------------------------------------
%N = sqrt(d);
% disk = FieldofView(N);
% FOV = reshape(disk,[N*N 1]);
% q = p.*FOV;
% penalty = sum(q);
%------------------------------------------------------------------

%------------------------------------------------------------------
%Full Image Fisrt-Order ITV Penalty
%------------------------------------------------------------------
penalty = sum(p);
%------------------------------------------------------------------
end